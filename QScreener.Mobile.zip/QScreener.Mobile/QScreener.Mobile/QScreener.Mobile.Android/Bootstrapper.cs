﻿using Pillar;
using QScreener.Mobile.Infrastructure;
using QScreener.Mobile.ViewModels;
using QScreener.Mobile.Views;
using Xamarin.Forms;

namespace QScreener.Mobile.Droid
{
    public class Bootstrapper : PillarBootstrapper
    {
        private IContainerAdapter container;

        public Bootstrapper(Xamarin.Forms.Application application) : base(application) { }

        protected override void BindViewModelsToViews(IViewFactory viewFactory)
        {
            viewFactory.Register<MainViewModel, MainView>();
            viewFactory.Register<LoginViewModel, LoginView>();
            viewFactory.Register<ScreeningViewModel, ScreeningView>();
            viewFactory.Register<ReportsViewModel, ReportsView>();
            viewFactory.Register<ScreenCategoryViewModel, ScreenCategoryView>();
            viewFactory.Register<ScreeneeProfileViewModel, ScreeneeProfileView>();
            viewFactory.Register<MetricsViewModel, MetricsView>();
        }

        protected override Page GetFirstPage(IViewFactory viewFactory)
        {
            return viewFactory.Resolve<MainViewModel>();
        }

        protected override void RegisterDependencies(IContainerAdapter container)
        {
            container.RegisterSingleton<DataProvider>();
            // viewmodels
            container.RegisterSingleton<MainViewModel>();
            container.RegisterSingleton<LoginViewModel>();
            container.RegisterSingleton<ScreeningViewModel>();
            container.RegisterSingleton<ReportsViewModel>();
            container.RegisterSingleton<ScreenCategoryViewModel>();
            container.RegisterSingleton<ScreeneeProfileViewModel>();
            container.RegisterSingleton<MetricsViewModel>();

            // views
            container.RegisterType<MainView>();
            container.RegisterType<LoginView>();
            container.RegisterType<ScreeningView>();
            container.RegisterType<ReportsView>();
            container.RegisterType<ScreenCategoryView>();
            container.RegisterType<ScreeneeProfileView>();
            container.RegisterType<MetricsView>();
        }

        protected override IContainerAdapter GetContainer()
        {
            if (null == container)
                container = new AutofacContainerAdapter();

            return container;
        }
    }
}