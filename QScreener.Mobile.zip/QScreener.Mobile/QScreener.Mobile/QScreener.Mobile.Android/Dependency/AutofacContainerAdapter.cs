﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Autofac;
using Autofac.Core;
using Pillar;

namespace QScreener.Mobile.Droid 
{
    public interface IAutofacContainerAdapter
    {
        void RegisterModule(IModule module);
    }

    public class AutofacContainerAdapter : IContainerAdapter, IAutofacContainerAdapter
    {
        private readonly ContainerBuilder _containerBuilder = new ContainerBuilder();
        private readonly Lazy<IContainer> _lazyContainer;

        public AutofacContainerAdapter()
        {
            _lazyContainer = new Lazy<IContainer>(() => _containerBuilder.Build());
        }

        public object Resolve(Type serviceType)
        {
            try
            {
                return _lazyContainer.Value.Resolve(serviceType);
            }
            catch (DependencyResolutionException ex)
            {
                return null;
            }

        }

        public void RegisterType(Type serviceType, Type implementationType)
        {
            _containerBuilder.RegisterType(implementationType).As(serviceType);
        }

        public void RegisterType(Type serviceType, Func<object> implementationFactory)
        {
            _containerBuilder.Register(ctx => implementationFactory()).As(serviceType);
        }

        public void RegisterSingleton(Type serviceType, Type implementationType)
        {
            _containerBuilder.RegisterType(implementationType).As(serviceType).SingleInstance();
        }

        public void RegisterSingleton(Type serviceType, object implementationInstance)
        {
            _containerBuilder.RegisterInstance(implementationInstance).As(serviceType).SingleInstance();
        }

        public void RegisterSingleton(Type serviceType, Func<object> implementationFactory)
        {
            _containerBuilder.Register(ctx => implementationFactory()).As(serviceType).SingleInstance();
        }

        public void RegisterModule(IModule module)
        {
            _containerBuilder.RegisterModule(module);
        }


    }
}