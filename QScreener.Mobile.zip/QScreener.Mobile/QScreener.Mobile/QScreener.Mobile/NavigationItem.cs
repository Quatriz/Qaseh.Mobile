﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QScreener.Mobile
{
    public class NavigationItem
    {
        public string Name { get; set; }

        public string ImagePath { get; set; }
    }
}
