﻿using System;
using System.Reflection;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QScreener.Mobile
{
    public partial class App : Application
    {
        public static bool IsUserLoggedIn { get; set; }
        public static LogonUser CurrentUser { get; set; }

        public App()
        {
            Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("Mjg5MDc0QDMxMzgyZTMyMmUzMEt1dUh1SllEckNKQkFEdWUyTWNvSTZsNTdlWTVCc3VFODJVNEk0dDgzakU9");


            InitializeComponent();

          

        }

       
         

        protected override void OnStart()
        {
         
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
