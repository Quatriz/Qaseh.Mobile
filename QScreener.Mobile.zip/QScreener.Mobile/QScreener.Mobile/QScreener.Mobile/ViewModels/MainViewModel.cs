﻿using Pillar;
using QScreener.Mobile.Infrastructure;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Xamarin.Forms;

namespace QScreener.Mobile.ViewModels
{
    public class MainViewModel : PillarViewModelBase
    {
        private INavigator navigator;
        
        private Command logoutCommand;
        private Command<object> itemTappedCommand; 

        private readonly ClickRegulator _clickRegulator = new ClickRegulator();

        private ObservableCollection<NavigationItem> navItems = new ObservableCollection<NavigationItem>();
        

        public MainViewModel(INavigator navigator)
        {
            this.navigator = navigator;

            this.NavigationItems = new ObservableCollection<NavigationItem>();

            NavigationItems.Add(new NavigationItem() { Name = "Screening", ImagePath = "img_" });

            NavigationItems.Add(new NavigationItem() { Name = "Reports", ImagePath = "img_" });
        }

        public ObservableCollection<NavigationItem> NavigationItems
        {
            get => navItems;
            set
            {
                navItems = value;

            }
        }

        public Command LogoutCommand
        {
            get
            {
                return this.logoutCommand ?? (this.logoutCommand = new Command(this.NavigateToLoginPage));
            }
        }

        public Command<object> ItemTappedCommand
        {
            get
            {
                return this.itemTappedCommand ?? (this.itemTappedCommand = new Command<object>(this.NavigateToNextPage));
            }
        }

       



        public override void ViewEntered()
        {
            if (!App.IsUserLoggedIn)
                navigator.PushModalAsync<LoginViewModel>();
        }




        public async void NavigateToLoginPage()
        {
            if (_clickRegulator.SetClicked(nameof(NavigateToLoginPage))) return;

            try
            {
                App.IsUserLoggedIn = false;
                App.CurrentUser = null;
                await navigator.PushModalAsync<LoginViewModel>();
            }
            catch (Exception ex)
            {

            }
            finally
            {
                _clickRegulator.ClickDone(nameof(NavigateToLoginPage));
            }

        }

        private async void NavigateToNextPage(object selectedItem)
        {
            if (_clickRegulator.SetClicked(nameof(NavigateToNextPage))) return;

            try
            {
                var item = selectedItem as Syncfusion.ListView.XForms.ItemTappedEventArgs;
                if (null != item)
                {
                    var data = item.ItemData as NavigationItem;

                    switch (data.Name)
                    {
                        case "Screening":
                            await navigator.PushModalAsync<ScreeningViewModel>();
                            break;
                        case "Reports":
                            await navigator.PushModalAsync<ReportsViewModel>();
                            break;
                    }
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                _clickRegulator.ClickDone(nameof(NavigateToNextPage));
            }
        }

       
    }
}
