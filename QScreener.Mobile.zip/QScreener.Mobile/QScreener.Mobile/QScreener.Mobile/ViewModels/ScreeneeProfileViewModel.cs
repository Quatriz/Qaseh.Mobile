﻿using Pillar;
using QScreener.Mobile.Infrastructure;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace QScreener.Mobile.ViewModels
{
    public class ScreeneeProfileViewModel : PillarViewModelBase
    {
        private string screenCategorySelection;
        private INavigator navigator;
        private readonly ClickRegulator _clickRegulator = new ClickRegulator();
        private Command<object> queCommand;

        public ScreeneeProfileViewModel(INavigator navigator)
        {
            this.navigator = navigator;
        }

        public Profile ScreeneeProfile { get; set; }

        public string ScreenCategorySelection 
        { 
            get => screenCategorySelection; 
            set => screenCategorySelection = value; 
        }
        
        public Command<object> QueCommand 
        {
            get
            {
                return this.queCommand ?? (this.queCommand = new Command<object>(this.NavigateToNextPage));
            }
        }

        private async void NavigateToNextPage(object selectedItem)
        {
            if (_clickRegulator.SetClicked(nameof(NavigateToNextPage))) return;

            try
            {
                await navigator.PushModalAsync<ScreenCategoryViewModel>(x=>x.ReloadCues(this.screenCategorySelection));
            }
            catch (Exception ex)
            {

            }
            finally
            {
                _clickRegulator.ClickDone(nameof(NavigateToNextPage));
            }
        }

    }
}
