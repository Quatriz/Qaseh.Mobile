﻿using Pillar;
using QScreener.Mobile.Infrastructure;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace QScreener.Mobile.ViewModels
{
    public class LoginViewModel : PillarViewModelBase
    {
        private INavigator navigator;
        private bool _areCredentialsInvalid;
        private string _username;
        private string _password;
      
        private readonly ClickRegulator _clickRegulator = new ClickRegulator();

        public LoginViewModel(INavigator navigator)
        {
            this.navigator = navigator;

            AuthenticateCommand = new Command(() =>
            {
                AreCredentialsInvalid = !UserAuthenticated(Username, Password);
                if (_areCredentialsInvalid)
                    return;

                App.CurrentUser = new LogonUser() { UserName = this.Username };
                App.IsUserLoggedIn = true;

                GoBack();
            });
        
        }

        public override void ViewEntering()
        {
            this.Username = "";
            this.Password = "";
        }

        private bool UserAuthenticated(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password)) // return false if Empty
            {
                return false;
            }

            return true;
        }

        private async void GoBack()
        {
            await navigator.PopModalAsync();
            await navigator.PopToRootAsync();
        }

        public ICommand AuthenticateCommand { get; set; }

        public bool AreCredentialsInvalid
        {
            get => _areCredentialsInvalid;
            set
            {
                _areCredentialsInvalid = value;
                OnPropertyChanged(nameof(AreCredentialsInvalid));
            }
        }

        public string Username
        {
            get => _username;
            set
            {
                if (value == _username) return;
                _username = value;
                OnPropertyChanged(nameof(Username));
            }
        }

        public string Password
        {
            get => _password;
            set
            {
                if (value == _password) return;
                _password = value;
                OnPropertyChanged(nameof(Password));
            }
        }

    
    }
}
