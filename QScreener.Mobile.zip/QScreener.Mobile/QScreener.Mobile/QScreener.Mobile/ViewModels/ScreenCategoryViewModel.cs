﻿using Pillar;
using QScreener.Mobile.Infrastructure;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Xamarin.Forms;

namespace QScreener.Mobile.ViewModels
{
    public class ScreenCategoryViewModel : PillarViewModelBase 
    {
        private INavigator navigator;
        private DataProvider dataProvider;
        private Command submitCommand;


        private readonly ClickRegulator _clickRegulator = new ClickRegulator();
        private ObservableCollection<Cue> cueItems = new ObservableCollection<Cue>();

        public ScreenCategoryViewModel(INavigator navigator, DataProvider dataProvider)
        {
            this.navigator = navigator;
            this.dataProvider = dataProvider;
        }


        public Command SubmitCommand
        {
            get
            {
                return this.submitCommand ?? (this.submitCommand = new Command(this.Submit));
            }
        }

        private void Submit()
        {
            navigator.PushModalAsync<MetricsViewModel>();
        }

        public void ReloadCues(string category)
        {
           
            var list = new List<Cue>();
            switch (category)
            {
                case "A":
                    list = dataProvider.ScreenCue_A();
                    break;
            }

            CueItems = new ObservableCollection<Cue>();

            foreach (var item in list)
                CueItems.Add(item);

        }

        public ObservableCollection<Cue> CueItems
        {
            get => cueItems;
            set
            {
                cueItems = value;

            }
        }
    }
}
