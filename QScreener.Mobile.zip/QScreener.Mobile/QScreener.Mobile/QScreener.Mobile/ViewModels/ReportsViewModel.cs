﻿using Pillar;
using System;
using System.Collections.Generic;
using System.Text;

namespace QScreener.Mobile.ViewModels
{
    public class ReportsViewModel : PillarViewModelBase
    {
    }
}
