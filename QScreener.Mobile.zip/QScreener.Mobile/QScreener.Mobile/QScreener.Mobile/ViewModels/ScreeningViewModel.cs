﻿using Pillar;
using QScreener.Mobile.Infrastructure;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Xamarin.Forms;

namespace QScreener.Mobile.ViewModels
{
    public class ScreeningViewModel : PillarViewModelBase
    {
        private INavigator navigator;
        private ObservableCollection<ScreeningItem> scItem = new ObservableCollection<ScreeningItem>();
        private Command<object> itemTappedCommand;

        private readonly ClickRegulator _clickRegulator = new ClickRegulator();

        public ScreeningViewModel(INavigator navigator)
        {
            this.navigator = navigator;

            LoadScreeningItems();
            
        }

        private void LoadScreeningItems()
        {
            this.ScreeningItems.Add(new ScreeningItem() { Name = "A", Description =  ScreeningCategory.A });
            this.ScreeningItems.Add(new ScreeningItem() { Name = "B", Description =  ScreeningCategory.B });
            this.ScreeningItems.Add(new ScreeningItem() { Name = "C", Description =  ScreeningCategory.C });
            this.ScreeningItems.Add(new ScreeningItem() { Name = "D", Description =  ScreeningCategory.D });
            this.ScreeningItems.Add(new ScreeningItem() { Name = "E", Description =  ScreeningCategory.E });
            this.ScreeningItems.Add(new ScreeningItem() { Name = "F", Description =  ScreeningCategory.F });
            this.ScreeningItems.Add(new ScreeningItem() { Name = "G", Description =  ScreeningCategory.G });
            this.ScreeningItems.Add(new ScreeningItem() { Name = "H", Description =  ScreeningCategory.H });
            this.ScreeningItems.Add(new ScreeningItem() { Name = "I", Description =  ScreeningCategory.I });
            this.ScreeningItems.Add(new ScreeningItem() { Name = "J", Description =  ScreeningCategory.J });
            this.ScreeningItems.Add(new ScreeningItem() { Name = "K", Description =  ScreeningCategory.K });
            this.ScreeningItems.Add(new ScreeningItem() { Name = "L", Description =  ScreeningCategory.L });
            this.ScreeningItems.Add(new ScreeningItem() { Name = "M", Description =  ScreeningCategory.M });
            this.ScreeningItems.Add(new ScreeningItem() { Name = "N", Description =  ScreeningCategory.N });


        }


        private async void NavigateToNextPage(object selectedItem)
        {
            if (_clickRegulator.SetClicked(nameof(NavigateToNextPage))) return;

            try
            {
                var item = selectedItem as Syncfusion.ListView.XForms.ItemTappedEventArgs;
                if (null != item)
                {
                    var data = item.ItemData as ScreeningItem;

                    if(null!=data)
                        await navigator.PushModalAsync<ScreeneeProfileViewModel>(x=>x.ScreenCategorySelection = data.Name);
                    
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                _clickRegulator.ClickDone(nameof(NavigateToNextPage));
            }
        }



        public Command<object> ItemTappedCommand
        {
            get
            {
                return this.itemTappedCommand ?? (this.itemTappedCommand = new Command<object>(this.NavigateToNextPage));
            }
        }


        public ObservableCollection<ScreeningItem> ScreeningItems
        {
            get => scItem;
            set
            {
                scItem = value;

            }
        }


    }
}
