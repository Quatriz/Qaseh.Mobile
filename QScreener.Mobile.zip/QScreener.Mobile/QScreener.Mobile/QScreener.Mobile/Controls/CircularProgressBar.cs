﻿using Xamarin.Forms;

namespace QScreener.Mobile.Controls
{
    public class CircularProgressBar : BaseProgressBar
    {
        
    }
}
