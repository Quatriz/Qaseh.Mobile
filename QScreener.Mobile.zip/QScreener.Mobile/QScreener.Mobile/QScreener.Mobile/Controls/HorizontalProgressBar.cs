﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QScreener.Mobile.Controls
{
    public class HorizontalProgressBar : BaseProgressBar
    {
    }
}
