﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace QScreener.Mobile.Controls
{
    public class FormsFloatingActionButton : Button
    {

    }
}
