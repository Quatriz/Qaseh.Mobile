﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QScreener.Mobile
{
    public class LogonUser
    {
        public string UserLogin { get; set; }

        public string UserName { get; set; }
    }
}
