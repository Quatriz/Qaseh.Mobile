﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QScreener.Mobile.Infrastructure
{
    public class Cue
    {
        public int Index { get; set; }

        public string Question { get; set; } 

        public bool Answer { get; set; }
    }
}
