﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QScreener.Mobile.Infrastructure
{
    public class Profile
    {
        public string Name { get; set; }

        public string IdentificationCardNo { get; set; }

        public string Age { get; set; }

        public string Gender { get; set; }
    }
}
