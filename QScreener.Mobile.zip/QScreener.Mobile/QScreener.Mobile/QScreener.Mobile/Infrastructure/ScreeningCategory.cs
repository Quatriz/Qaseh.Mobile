﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QScreener.Mobile.Infrastructure
{
    public class ScreeningCategory
    {
        public const string A = "Sensori Visual / Penglihatan" ; 
        public const string B = "Sensori Auditori / Pendengaran";
        public const string C = "Verbal / Pertuturan";
        public const string D = "Ketidakfungsian Vestibular";
        public const string E = "Ketidakmatangan";
        public const string F = "Autisme";
        public const string G = "Sindrom Asperger (SA)";
        public const string H = "Attention Deficit Hyperactive Disorder";
        public const string I = "Disleksia";
        public const string J = "Diskalkulia";
        public const string K = "Ketidakupayaan Intelek";
        public const string L = "Pintar dan Berbakat";
        public const string M = "Masalah Pembelajaran Spesifik (SLD)";
        public const string N = "Sensori Taktil / Sentuhan";

    }
}
