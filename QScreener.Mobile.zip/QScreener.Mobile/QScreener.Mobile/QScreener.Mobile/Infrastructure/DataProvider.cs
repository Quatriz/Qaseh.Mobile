﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QScreener.Mobile.Infrastructure
{
    public class DataProvider
    {
        public List<Cue> ScreenCue_A()
        {
            var result = new List<Cue>();

            result.Add(new Cue() { Index = 1, Question = "Mata tiada koordinasi; setiap satu mata bergerak dalam arah berbeza" });
            result.Add(new Cue() { Index = 2, Question = "Pergerakan mata keterlaluan / liar" });
            result.Add(new Cue() { Index = 3, Question = "Mata terkebil-kebil"});
            result.Add(new Cue() { Index = 4, Question = "Selalu menyapu mata" });
            result.Add(new Cue() { Index = 5, Question = "Selalu ada jangkitan pada mata ( mata merah,berselaput keras )" });
            result.Add(new Cue() { Index = 6, Question = "Mata berair." });
            result.Add(new Cue() { Index = 7, Question = "Sukar membaca." });
            result.Add(new Cue() { Index = 8, Question = "Buku / bahan bacaan dirapatkan pada mata." });
            result.Add(new Cue() { Index = 9, Question = "Kepala ditundukkan rapat ke meja." });
            result.Add(new Cue() { Index = 10, Question = "Kepala senget atau condong semasa menulis." });
            result.Add(new Cue() { Index = 11, Question = "Barisan teks tercicir semasa membaca." });
            result.Add(new Cue() { Index = 12, Question = "Perkataan dalam teks tercicir semasa membaca." });
            result.Add(new Cue() { Index = 13, Question = "Keliru dengan warna" });
            result.Add(new Cue() { Index = 14, Question = "Posisi badan yang sukar semasa membaca atau menulis" });
            result.Add(new Cue() { Index = 15, Question = "Menyepetkan,mengecilkan mata, kening berkerut atau kepala condong ke depan semasa menyalin nota di papan tulis." });
            result.Add(new Cue() { Index = 16, Question = "Kesalahan dalam menyalin, keliru dengan simbol." });
            result.Add(new Cue() { Index = 17, Question = "Kepala bergerak-gerak semasa membaca." });
            result.Add(new Cue() { Index = 18, Question = "Berada sangat dekat dengan televisyen atau papan tulis." });
            result.Add(new Cue() { Index = 19, Question = "Buku latihan tidak kemas." });
            result.Add(new Cue() { Index = 20, Question = "Kerap sakit kepala atau pening." });
            result.Add(new Cue() { Index = 21, Question = "Selalu mengadu penglihatan kabur." });

            return result;
        }
    }
}
