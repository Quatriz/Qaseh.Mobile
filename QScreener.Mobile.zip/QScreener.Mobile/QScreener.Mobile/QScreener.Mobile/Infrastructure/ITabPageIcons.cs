﻿using System;
using System.Collections.Generic;
using System.Text;

namespace QScreener.Mobile.Infrastructure
{
    public interface ITabPageIcons
    {
        string GetIcon();
        string GetSelectedIcon();
    }
}
